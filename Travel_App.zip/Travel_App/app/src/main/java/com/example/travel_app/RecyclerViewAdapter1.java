package com.example.travel_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter1 extends RecyclerView.Adapter<RecyclerViewAdapter1.ViewHolder>
{
    placeList1[] placeListData1;
    Context context;


    public RecyclerViewAdapter1(placeList1[] placeListData1, MainActivity activity) {
        this.placeListData1 = placeListData1;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.place_layout1,parent,false);
        ViewHolder viewHolder1 = new ViewHolder(view);
        return viewHolder1;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        final placeList1 placeListData_final1  = placeListData1[position];

        holder.topRowTitleTextView.setText(placeListData_final1.getPlaceTitle1());
        holder.topRowImageView.setImageResource(placeListData_final1.getPlaceImage1());

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(placeListData_final1.getPlaceTitle1() == "Paris")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    ParisFragment parisFragment = new ParisFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, parisFragment).addToBackStack(null).commit();
                }
                else if(placeListData_final1.getPlaceTitle1() == "Dubai")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    DubaiFragment dubaiFragment = new DubaiFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, dubaiFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Barcelona")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    BarcelonaFragment barcelonaFragment = new BarcelonaFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec,barcelonaFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Sydney")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    SydneyFragment sydneyFragment = new SydneyFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, sydneyFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "London")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    LondonFragment londonFragment = new LondonFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, londonFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Singapore")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    SingaporeFragment singaporeFragment = new SingaporeFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, singaporeFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Tokyo")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    TokyoFragment tokyoFragment = new TokyoFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, tokyoFragment).addToBackStack(null).commit();

                }
                else if(placeListData_final1.getPlaceTitle1() == "Newyork")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    NewyorkFragment newyorkFragment = new NewyorkFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, newyorkFragment).addToBackStack(null).commit();

                }

                else
                {
                    Toast.makeText(context, placeListData_final1.getPlaceTitle1(), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    @Override
    public int getItemCount() {
        return placeListData1.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView topRowTitleTextView;
        ImageView topRowImageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            topRowTitleTextView = itemView.findViewById(R.id.topRowTitleTextView);
            topRowImageView = itemView.findViewById(R.id.topRowImageView);
        }
    }
}
