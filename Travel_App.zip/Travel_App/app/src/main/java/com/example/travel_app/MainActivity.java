package com.example.travel_app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView, recyclerView1;
    RecyclerViewAdapter recyclerViewAdapter;
    RecyclerViewAdapter1 recyclerViewAdapter1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView1 = findViewById(R.id.recyclerView1);


        placeList[] placeListData_final = new placeList[]{
                new placeList("Paris", "Paris is the second most visited city in the world and the most visited city in Europe!", R.drawable.paris),
                new placeList("Dubai", "Dubai is one of the world's most popular tourist destinations with the second most five-star hotels in the world.", R.drawable.dubai),
                new placeList("London", "London is clearly one of the most popular cities in the world!.", R.drawable.london),
                new placeList("Sydney", "Sydney  is the capital city of the state of New South Wales.", R.drawable.sydney),
                new placeList("Singapore", "Green and innovative, Singapore is a city designed with the future in mind.", R.drawable.singapore),
                new placeList("Newyork", "New York, or the city where dreams are made!", R.drawable.newyork),
                new placeList("Tokyo", "If there was a city that lived in the future, Tokyo is it!", R.drawable.tokyo),
                new placeList("Barcelona", "Barcelona is generous with its fresh sea bounty and world-class architecture.", R.drawable.barcelona),

        };

        placeList1[] placeListData_final1  = new placeList1[]
                {
                        new placeList1("Sydney",R.drawable.sydney),
                        new placeList1("London", R.drawable.london),
                        new placeList1("Paris", R.drawable.paris),
                        new placeList1("Barcelona", R.drawable.barcelona),
                        new placeList1("Tokyo", R.drawable.tokyo),
                        new placeList1("Newyork",R.drawable.newyork),
                        new placeList1("Singapore", R.drawable.singapore),
                        new placeList1("Dubai",R.drawable.dubai),

                };




        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        recyclerView1.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        recyclerViewAdapter = new RecyclerViewAdapter(placeListData_final, MainActivity.this);
        recyclerViewAdapter1 = new RecyclerViewAdapter1(placeListData_final1, MainActivity.this);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerView1.setAdapter(recyclerViewAdapter1);


    }
}