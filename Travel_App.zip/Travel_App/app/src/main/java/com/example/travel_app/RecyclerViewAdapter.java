package com.example.travel_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>
{
    placeList[] placeListData;
    Context context;
    private Object TokyoFragment;
    private Object LondonFragment;


    public RecyclerViewAdapter(placeList[] placeListData, MainActivity activity) {
        this.placeListData = placeListData;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.place_layout,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        final placeList placeListData_final  = placeListData[position];

        holder.rowTitleTextView.setText(placeListData_final.getPlaceTitle());
        holder.rowDescriptionTextView.setText(placeListData_final.getPlaceDescription());
        holder.rowImageView.setImageResource(placeListData_final.getPlaceImage());

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            private Object BarcelonaFragment;

            @Override
            public void onClick(View v)
            {
               if(placeListData_final.getPlaceTitle() == "Paris")
               {
                   AppCompatActivity activity = (AppCompatActivity) v.getContext();
                   ParisFragment parisFragment = new ParisFragment();
                   activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, parisFragment).addToBackStack(null).commit();
               }
               else if(placeListData_final.getPlaceTitle() == "Dubai")
               {
                   AppCompatActivity activity = (AppCompatActivity) v.getContext();
                   DubaiFragment dubaiFragment = new DubaiFragment();
                   activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, dubaiFragment).addToBackStack(null).commit();

               }
               else if(placeListData_final.getPlaceTitle() == "Sydney")
               {
                   AppCompatActivity activity = (AppCompatActivity) v.getContext();
                   SydneyFragment sydneyFragment = new SydneyFragment();
                   activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, sydneyFragment).addToBackStack(null).commit();

               }
               else if(placeListData_final.getPlaceTitle() == "Singapore")
               {
                   AppCompatActivity activity = (AppCompatActivity) v.getContext();
                   SingaporeFragment singaporeFragment = new SingaporeFragment();
                   activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, singaporeFragment).addToBackStack(null).commit();

               }

               else if(placeListData_final.getPlaceTitle() == "Barcelona")
               {
                   AppCompatActivity activity = (AppCompatActivity) v.getContext();
                   BarcelonaFragment barcelonaFragment = new BarcelonaFragment();
                   activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, barcelonaFragment).addToBackStack(null).commit();

               }

               else if(placeListData_final.getPlaceTitle() == "Tokyo")
               {
                   AppCompatActivity activity = (AppCompatActivity) v.getContext();
                   TokyoFragment tokyoFragment = new TokyoFragment();
                   activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec,tokyoFragment).addToBackStack(null).commit();

               }
               else if(placeListData_final.getPlaceTitle() == "Newyork")
               {
                   AppCompatActivity activity = (AppCompatActivity) v.getContext();
                   NewyorkFragment newyorkFragment = new NewyorkFragment();
                   activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec,newyorkFragment).addToBackStack(null).commit();

               }
               else if(placeListData_final.getPlaceTitle() == "London")
               {
                   AppCompatActivity activity = (AppCompatActivity) v.getContext();
                   LondonFragment londonFragment = new LondonFragment();
                   activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec,londonFragment).addToBackStack(null).commit();

               }
               else
               {
                   Toast.makeText(context, placeListData_final.getPlaceTitle(), Toast.LENGTH_SHORT).show();
               }

            }
        });
    }


    @Override
    public int getItemCount() {
        return placeListData.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView rowTitleTextView;
        TextView rowDescriptionTextView;
        ImageView rowImageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            rowTitleTextView = itemView.findViewById(R.id.rowTitleTextView);
            rowDescriptionTextView = itemView.findViewById(R.id.rowDescriptionTextView);
            rowImageView = itemView.findViewById(R.id.rowImageView);
        }
    }
}
